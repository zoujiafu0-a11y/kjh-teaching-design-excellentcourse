# 工具参数

使用当前环境提供的Python（需要lxml），PowerShell脚本需要Windows与本机Office。下列参数由Codex整理，不让用户编写配置。所有报告路径须是新路径，禁止覆盖源文件。

```text
python scripts/package_tools.py inspect 输入文件 --report work/inventory.json
python scripts/package_tools.py patch 输入文件 输出副本 --changes work/changes.json --report work/patch.json
python scripts/package_tools.py compare 输入文件 输出副本 --report work/compare.json
```

changes.json是数组，每项含old和new完整段落，可选part和index定位。必须唯一匹配；重复、无变化、复杂域或链接、已有输出均拒绝。先inspect再制定修改，禁止按旧课索引盲替。此工具保护非文字结构，不负责混合格式语义或视觉适配。compare仅适用于文字替换的严格保真检查，新增图表或动画须另按授权对象比对。

```text
powershell -File scripts/office_ppt.ps1 -InputFile 课件.pptx -OutputDir work/render_r1 -Mode Render
powershell -File scripts/office_ppt.ps1 -InputFile 课件.pptx -OutputDir work/playback_r1 -Mode Playback
```

媒体检查另传-MediaSlide（真实页码）、-MediaShape（真实形状名称）和-SeekMilliseconds（片段内的有效位置）。脚本实际启动放映，不将点击状态成功写成视觉通过。视觉逐页检查及素材审核另留记录。

新增逐对象动画使用：
```text
powershell -File scripts/animate_objects.ps1 -InputFile 输入.pptx -OutputFile 新副本.pptx -PlanFile work/animation_plan.json -ReportFile work/animation_build.json
```
计划为数组，每项含slide、shape、expectedShapeId、effect。effect支持Fly、Wipe、Zoom、Fade；默认单击触发，持续0.4秒。先读取真实形状信息，只为已授权内容对象添加，不处理固定封面。已有动画需先核对，不盲目重复添加。完成后另执行Render与Playback，构建成功不等于放映验收。

实际动画画面可使用同目录capture_show.ps1传给office_ppt.ps1的-CaptureScript。该工具只定位指定窗口或唯一PowerPoint放映窗口，失败须记录，不回退为整屏截图或静态导出图。当前支持Windows窗口类及中英文放映标题；其他语言需按实际窗口信息适配。
