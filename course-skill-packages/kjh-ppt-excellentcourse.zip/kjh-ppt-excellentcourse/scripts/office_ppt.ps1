param([Parameter(Mandatory=$true)][string]$InputFile,[Parameter(Mandatory=$true)][string]$OutputDir,[ValidateSet('Render','Playback')][string]$Mode='Render',[int]$MediaSlide=0,[string]$MediaShape='', [int]$SeekMilliseconds=1000,[string]$CaptureScript='')
$ErrorActionPreference='Stop'
$source=(Resolve-Path -LiteralPath $InputFile).Path
if([IO.Path]::GetExtension($source) -ne '.pptx'){throw 'Expected PPTX'}
$out=[IO.Path]::GetFullPath($OutputDir)
if(Test-Path -LiteralPath $out){throw 'Use a new evidence directory'}
New-Item -ItemType Directory -Path $out | Out-Null
$before=(Get-FileHash -LiteralPath $source).Hash
$pp=$null;$p=$null;$win=$null;$events=@();$media=$null
try {
 $pp=New-Object -ComObject PowerPoint.Application
 $p=$pp.Presentations.Open($source,-1,0,0)
 if($Mode -eq 'Render') {
  for($i=1;$i -le $p.Slides.Count;$i++) {$p.Slides.Item($i).Export((Join-Path $out ('slide_{0:d2}.png' -f $i)),'PNG',1600,900)}
  $p.SaveAs((Join-Path $out 'slides.pdf'),32)
 } else {
  $p.SlideShowSettings.ShowType=2;$p.SlideShowSettings.ShowWithAnimation=-1
  $win=$p.SlideShowSettings.Run()
  for($i=1;$i -le $p.Slides.Count;$i++) {
   $win.View.GotoSlide($i,-1);Start-Sleep -Milliseconds 200
   if($CaptureScript){ & $CaptureScript -Path (Join-Path $out ('show_{0:d2}_00.png' -f $i)) -WindowHandle $win.HWND | Out-Null }
   $count=$win.View.GetClickCount();$played=@();$effects=@()
   foreach($effect in $p.Slides.Item($i).TimeLine.MainSequence){
    $effects += [pscustomobject]@{shape=$effect.Shape.Name;shapeId=$effect.Shape.Id;effectType=$effect.EffectType;trigger=$effect.Timing.TriggerType}
   }
   for($k=1;$k -le $count;$k++) {
    $win.View.GotoClick($k);Start-Sleep -Milliseconds 800
    $actual=$win.View.GetClickIndex();$played+=$actual
    if($CaptureScript){ & $CaptureScript -Path (Join-Path $out ('show_{0:d2}_{1:d2}.png' -f $i,$k)) -WindowHandle $win.HWND | Out-Null }
    if($actual -ne $k){throw "Playback mismatch on slide $i click $k"}
   }
   $events += [pscustomobject]@{slide=$i;actualClicks=$count;played=$played;effects=$effects;visualReview='NOT_RUN';clickStatePass=$true}
  }
  if($MediaSlide -gt 0) {
   if(-not $MediaShape){throw 'MediaShape required'}
   $win.View.GotoSlide($MediaSlide,-1)
   $shape=$p.Slides.Item($MediaSlide).Shapes.Item($MediaShape)
   $player=$win.View.Player($shape.Id);$player.Play();Start-Sleep -Seconds 2
   $position=$player.CurrentPosition;$player.Pause();$paused=$player.State
   $player.CurrentPosition=$SeekMilliseconds;$player.Play();Start-Sleep -Seconds 2
   $seek=$player.CurrentPosition;$player.Stop()
   $returnSlide=[Math]::Max(1,$MediaSlide-1);$win.View.GotoSlide($returnSlide,-1)
   $media=[pscustomobject]@{slide=$MediaSlide;shape=$MediaShape;position=$position;pausedState=$paused;seekPosition=$seek;returnedSlide=$win.View.Slide.SlideIndex;pass=($position -gt 0 -and $paused -eq 1 -and $seek -gt $SeekMilliseconds)}
   if(-not $media.pass){throw 'Media playback state check failed'}
  }
 }
 [pscustomobject]@{file=$source;sha256=$before;mode=$Mode;slides=$p.Slides.Count;application='Microsoft PowerPoint';events=$events;media=$media;visualReview='NOT_RUN'} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'receipt.json') -Encoding utf8
} catch {
 [pscustomobject]@{status='FAIL';error=$_.Exception.Message;events=$events} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $out 'error.json') -Encoding utf8
 throw
} finally {
 if($win){try{$win.View.Exit()}catch{}}
 if($p){try{$p.Saved=-1;$p.Close()}catch{}}
 # PowerPoint may be a shared singleton: do not quit or close unrelated user decks.
 if($pp){try{if($pp.Presentations.Count -eq 0){$pp.Quit()}}catch{};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($pp)}
}
if((Get-FileHash -LiteralPath $source).Hash -ne $before){throw 'Read-only input changed'}
Get-Content -LiteralPath (Join-Path $out 'receipt.json')
