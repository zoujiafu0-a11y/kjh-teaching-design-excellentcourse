param([Parameter(Mandatory=$true)][string]$InputFile,[Parameter(Mandatory=$true)][string]$OutputFile,[Parameter(Mandatory=$true)][string]$PlanFile,[Parameter(Mandatory=$true)][string]$ReportFile)
$ErrorActionPreference='Stop'
$source=(Resolve-Path -LiteralPath $InputFile).Path
$target=[IO.Path]::GetFullPath($OutputFile);$report=[IO.Path]::GetFullPath($ReportFile)
if($source -eq $target -or (Test-Path -LiteralPath $target) -or (Test-Path -LiteralPath $report)){throw 'Use new output and report paths'}
if($report -eq $source -or $report -eq $target){throw 'Report must not replace a presentation'}
$plan=Get-Content -LiteralPath $PlanFile -Raw -Encoding utf8 | ConvertFrom-Json
$codes=@{Fly=2;Wipe=22;Zoom=23;Fade=10}
$hash=(Get-FileHash -LiteralPath $source).Hash;$pp=$null;$p=$null;$events=@()
try {
 $pp=New-Object -ComObject PowerPoint.Application
 $p=$pp.Presentations.Open($source,-1,0,0)
 foreach($item in $plan) {
  if([int]$item.slide -lt 2 -or [int]$item.slide -gt $p.Slides.Count){throw 'Do not animate fixed cover or invalid slide'}
  if(-not $codes.ContainsKey([string]$item.effect)){throw 'Unsupported effect'}
  $slide=$p.Slides.Item([int]$item.slide);$shape=$slide.Shapes.Item([string]$item.shape)
  if($shape.Id -ne [int]$item.expectedShapeId){throw 'Shape identity changed'}
  $e=$slide.TimeLine.MainSequence.AddEffect($shape,$codes[[string]$item.effect],0,1)
  $e.Timing.Duration=0.4
  $events+=[pscustomobject]@{slide=$item.slide;shape=$shape.Name;shapeId=$shape.Id;effectType=$e.EffectType;trigger=$e.Timing.TriggerType}
 }
 $p.SaveAs($target,24)
 [pscustomobject]@{source=$source;sourceHash=$hash;output=$target;sha256=(Get-FileHash -LiteralPath $target).Hash;added=$events;playback='NOT_RUN';visualReview='NOT_RUN'} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $report -Encoding utf8
} finally {
 if($p){$p.Saved=-1;$p.Close()}
 if($pp){if($pp.Presentations.Count -eq 0){$pp.Quit()};[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($pp)}
}
if((Get-FileHash -LiteralPath $source).Hash -ne $hash){throw 'Source changed'}
Get-Content -LiteralPath $report
