param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][long]$WindowHandle)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
if(-not ('CourseWindowCapture' -as [type])) {
Add-Type @'
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;
public class CourseWindowCapture {
 [StructLayout(LayoutKind.Sequential)] public struct RECT {public int Left,Top,Right,Bottom;}
 public delegate bool EnumProc(IntPtr h,IntPtr p);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb,IntPtr p);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetClassName(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h,StringBuilder s,int n);
 [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
 public static IntPtr FindShow(){var found=new List<IntPtr>();EnumWindows((h,p)=>{var s=new StringBuilder(256);GetClassName(h,s,256);var t=new StringBuilder(512);GetWindowText(h,t,512);if((s.ToString()=="screenClass" || (s.ToString()=="PPTFrameClass" && (t.ToString().Contains("幻灯片放映") || t.ToString().Contains("Slide Show")))) && IsWindowVisible(h))found.Add(h);return true;},IntPtr.Zero);if(found.Count!=1)throw new Exception("Expected exactly one visible PowerPoint slide show; found "+found.Count);return found[0];}
 [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr v);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h,IntPtr after,int x,int y,int w,int z,uint f);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h,IntPtr dc,uint flags);
}
'@
}
$h=if($WindowHandle -ne 0){[IntPtr]$WindowHandle}else{[CourseWindowCapture]::FindShow()}
$prev=[CourseWindowCapture]::SetThreadDpiAwarenessContext([IntPtr](-4))
try {
 [void][CourseWindowCapture]::SetForegroundWindow($h)
 Start-Sleep -Milliseconds 150
 $r=New-Object CourseWindowCapture+RECT
 if(-not [CourseWindowCapture]::GetWindowRect($h,[ref]$r)){throw ('Window rectangle unavailable: '+$WindowHandle)}
 $b=New-Object Drawing.Bitmap(($r.Right-$r.Left),($r.Bottom-$r.Top))
 $g=[Drawing.Graphics]::FromImage($b);$dc=$g.GetHdc()
 try {$ok=[CourseWindowCapture]::PrintWindow($h,$dc,2)}finally{$g.ReleaseHdc($dc)}
 if(-not $ok){throw 'PrintWindow failed; do not substitute a static slide export'}
 $b.Save([IO.Path]::GetFullPath($Path),[Drawing.Imaging.ImageFormat]::Png)
} finally {
 if($g){$g.Dispose()};if($b){$b.Dispose()}
 [void][CourseWindowCapture]::SetThreadDpiAwarenessContext($prev)
}
